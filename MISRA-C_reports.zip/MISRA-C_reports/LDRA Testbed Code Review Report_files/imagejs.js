var temp_str ='<img src="file:///proj/xhdsswstaff/ssw/tools/LDRA/Non-Safety/ldra_toolsuite954/images/';
var base_str ='<a href="file:///proj/xhdsswstaff/ssw/tools/LDRA/Non-Safety/ldra_toolsuite954/';
function TBLaunchit(eParam, eOtherParam)
{
var RunLine;
RunLine=  '"' + '/proj/xhdsswstaff/ssw/tools/LDRA/Non-Safety/ldra_toolsuite954/tbbrowse' + '"| '
 + '"' + eParam + '"'   + '-Start=' + eOtherParam + ' ';
LDRATBLaunch.ExecuteIt(RunLine);
}
